class Config(object):
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://peter:foxfordccl9379@budgetdb.cozn4jwwelqb.eu-west-1.rds.amazonaws.com:3306/budgetSchema"
    DEBUG = True